import java.util.Scanner;
import java.util.Random;

class Game {
    private int compGuess;
    private int userGuess;
    private int noofGuesses;
    
    public Game() {
        Random random = new Random();       //Constructors parts- generating random numbers 
        compGuess = random.nextInt(101);
        noofGuesses = 0;                    //initilaizing number of guesses 
    }
    
    public void takeUserInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Guess the Number game!");
        System.out.println("I have selected a random number between 0 and 100.");
        System.out.println("Let's see if you can guess it!");

        while (compGuess != userGuess){
            System.out.print("\nEnter your guess: ");
            userGuess = scanner.nextInt();
            noofGuesses++;

            if (userGuess < compGuess) {
                System.out.println("Your guess is low. Try a higher number.");
            } else if (userGuess > compGuess) {
                System.out.println("Your guess is high. Try a lower number.");
            } else {
                System.out.println("\n Congratulations! You guessed the correct number.");
                System.out.println("\n You took " + noofGuesses + " guesses.");
                 if (noofGuesses < 5){
                    System.out.println(" You are a great player!!!!");
                }else if (noofGuesses >= 5 && noofGuesses < 15){
                System.out.println(" You are on your way to become a great player!!");
                }else if (noofGuesses >= 15 && noofGuesses < 30){
                System.out.println(" You need a bit of practice!");
                }else if (noofGuesses >= 30 && noofGuesses < 60){
                System.out.println(" You need a lot of practice!"); 
                }else
                System.out.println(" You don't know how to play this game, please learn first!!!!"); 
 
            }
        }

        scanner.close();
    }

    public boolean isCorrectNumber() {
        return noofGuesses > 0 && compGuess == userGuess;
    }
    
    public int getNoofGuesses() {
        return noofGuesses;
    }

    public void setNoofGuesses(int n) {
        noofGuesses = n;
    }
    
    public int getCompGuess() {
        return compGuess;
    }

    public void setCompGuess(int g) {
        compGuess = g;
    }
}

public class Main {
    public static void main(String[] args) {
        Game play = new Game(); // Instantiation
        play.takeUserInput();
    }
}

