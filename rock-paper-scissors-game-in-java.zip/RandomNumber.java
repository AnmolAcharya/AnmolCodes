import java.util.Random;
import java.util.Scanner;

public class RandomNumber {
    public static void main(String[] args) {
        System.out.println("\n Welcome to ROCK PAPER SCISSORS GAME!");
        System.out.println("\n In this game: \n Choose \n 0-Rock, \n 1-Scissors, \n 2-Paper");
        Random rand = new Random();
        
        int rounds = 0;
        int userScore = 0;
        while (rounds < 3) {
            rounds++;
            System.out.println("\nRound " + rounds);


        // Generate a random number between 0 and 2
        int compGuess = rand.nextInt(3);
        
    
        //Let the user enter their choice from 0-2
        Scanner user = new Scanner(System.in);
        System.out.print("Please Enter your choice: ");
        int input = user.nextInt();
        String userinput;
        switch (input){
            case 0:
                userinput = "ROCK";
                System.out.println("\n You chose ROCK");
                break;
                
            case 1:
                userinput = "Scissors";
                System.out.println("\n You chose Scissors");
                break;
                
            case 2: 
                userinput = "Paper";
                 System.out.println("\n You chose PAPER");
                break;
            default:
                System.out.println("\n You selected an invalid option");
        }
        
        
        //what number goes to whom part in switch case 
        
        String computer;
        switch (compGuess){
            case 0:
                computer = "ROCK";
                System.out.println("\n The computer chose ROCK");
                break;
                
            case 1:
                computer = "Scissors";
                System.out.println("\n The computer chose Scissors");
                break;
                
            case 2: 
                computer = "Paper";
                 System.out.println("\n The computer chose PAPER");
                break;
        }
         
        // comparing/deciding the winners in each of the cases 
        
        if (input == 0 && compGuess == 1 ){
            System.out.println("\n You win this one!!!");
            userScore++;
        }
        else if  (input == 1 && compGuess == 0 ){
            System.out.println("\n You lost!!!! Computer wins this one!!!");
        }
         else if  (input == 1 && compGuess == 1 ){
            System.out.println("\n It's a DRAW!!!");
        }
        else if  (input == 0 && compGuess == 0 ){
            System.out.println("\n It's a DRAW!!!");
        }
       else if  (input == 2 && compGuess == 0 ){
            System.out.println("\n You win this one!!!");
            userScore++;
        }
         else if  (input == 0 && compGuess == 2 ){
            System.out.println("\n You lost!!!! Computer wins this one!!!");
        }
         else if  (input == 1 && compGuess == 2 ){
            System.out.println("\n You win this one!!!");
            userScore++;
        }
         else if  (input == 2 && compGuess == 1 ){
            System.out.println("\n You lost!!!! Computer wins this one!!!");
         }
         else if  (input == 2 && compGuess == 2 ){
            System.out.println("\n It's a DRAW!!!");
        }
        else {
            System.out.println("\n Invalid error  !!!!");
        }
       }
       System.out.println("\n Game over!");
       // Determine the overall winner based on user's score
        System.out.print("\n Results of the match: ");
        if (userScore > 1) {
            System.out.println("\n Congratulations! You are the winner of this game!");
        } else if (userScore == 1) {
            System.out.println("\n You did well, but didn't win enough rounds.");
        } else {
            System.out.println("\n Sorry, you didn't win any rounds. Better luck next time!");
        }
        
    
    }
}
